import React from "react";
import Navbar from "./components/layout/Navbar";

const App = () => {
  return (
    <>
      <Navbar />
    </>
  );
};

export default App;
