import React, { useState } from "react";
import {
  FaBookmark,
  FaComment,
  FaExpand,
  FaInfoCircle,
  FaPhoneAlt,
  FaQuestionCircle,
  FaServicestack,
  FaUncharted,
} from "react-icons/fa";
import { Sidebar, Menu, MenuItem, SubMenu } from "react-pro-sidebar";

const Navbar = () => {
  const [collapse, setCollapse] = useState(false);
  const toggle = () => {
    setCollapse(!collapse);
  };
  return (
    <>
      <Sidebar
        collapsed={collapse}
        backgroundColor="rgb(15,23,42)"
        className="text-white"
      >
        <div className="logo-container-sidebar my-9">
          <h2 className="text-2xl text-gray-300 my-6 py-1 px-3 text-center">
            Heading
          </h2>
        </div>
        <div className="item-container-sidebar my-9">
          <h2 className="text-md text-gray-300 my-3 py-1 px-3 mx-3 text-center flex gap-9 items-center hover:text-orange-500">
            <span className="mx-2 text-xl">
              <FaBookmark />
            </span>
            <span>Projects</span>
          </h2>
          <h2 className="text-md text-gray-300 my-3 py-1 px-3 mx-3 text-center flex gap-9 items-center hover:text-orange-500">
            <span className="mx-2 text-xl">
              <FaComment />
            </span>
            <span>Testimonial</span>
          </h2>
          <h2 className="text-md text-gray-300 my-3 py-1 px-3 mx-3 text-center flex gap-9 items-center hover:text-orange-500">
            <span className="mx-2 text-xl">
              <FaServicestack />
            </span>
            <span>Services</span>
          </h2>
          <h2 className="text-md text-gray-300 my-3 py-1 px-3 mx-3 text-center flex gap-9 items-center hover:text-orange-500">
            <span className="mx-2 text-xl">
              <FaInfoCircle />
            </span>
            <span>About</span>
          </h2>
          <h2 className="text-md text-gray-300 my-3 py-1 px-3 mx-3 text-center flex gap-9 items-center hover:text-orange-500">
            <span className="mx-2 text-xl">
              <FaPhoneAlt />
            </span>
            <span>Contact</span>
          </h2>
          <h2 className="text-md text-gray-300 my-3 py-1 px-3 mx-3 text-center flex gap-9 items-center hover:text-orange-500">
            <span className="mx-2 text-xl">
              <FaQuestionCircle />
            </span>
            <span>Help</span>
          </h2>
        </div>
        <div className="empty-space my-9">&nbsp;</div>
        <button
          className="btn bg-slate-900 text-white hover:bg-slate-800 m-3"
          onClick={toggle}
        >
          <FaExpand />
        </button>
      </Sidebar>
    </>
  );
};

export default Navbar;
